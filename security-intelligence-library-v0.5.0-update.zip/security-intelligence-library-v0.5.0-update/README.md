# Security Intelligence Library

Cybersecurity / Identity Security / AI Security / Regulation / Management View の公開情報をMarkdownで蓄積し、Zensical + GitHub Pagesで公開するナレッジベースです。

## v0.5.0

- HomeをLatest Intelligence 6件に整理
- Monthly Intelligence Archiveを追加
- August 2026 Executive Summaryを追加
- Topicsをクリック可能に変更
- AboutをEditorial Policyへ拡張
- Source Tier / Evidence / Urgency / AI利用 / Correction / Disclaimerを明文化
- Front MatterをMetadataのSingle Source of Truthに変更
- 空のPPT導線を非表示化
- 主要主張にInline Footnoteを追加
- CIでFront Matter、必須章、内部リンク、参考URLを検証

## Local check

```bash
python scripts/sync_article_metadata.py
python scripts/check_content.py
zensical build --clean --strict
```
